
<?php
?>

</section>
<div class="foot">

    <footer class="text-center text-white" style="background-color: red;">

        <div class="container p-4 pb-0">

            <div class="foot1">
                <p class="d-flex justify-content-center align-items-center">
                    <span class="me-3">Register for free</span>
                    <button type="button" class="btn btn-outline-light btn-rounded">
                        <a style="color:white;" href="<?php echo APPLICATION_PATH?>index.php?register=true">Sign up</a>

                    </button>
                </p>
            </div>

        </div>

        <div class="text-center p-3" style="background-color: darkred;">
            © 2020 Copyright:
            <a class="text-white" href="https://www.manutd.com/">Manchester United</a>
        </div>
    </footer>

</div>
</main>
</body>
</html>
<style>
    .foot {
        position:fixed;
        bottom:0;
        width:100%;
        height:60px;
        background:#6cf;
        opacity: 45%;
    }

</style>
