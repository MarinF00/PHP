<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_DATABASE', 'shop');

define('APPLICATION_PATH', '/FenOLX/');
define('IMG_PATH', '/FenOLX/views/img/');
define('CONTROLLERS_PATH', 'controllers/');
define('MODEL_PATH', 'models/');
define('REPOSITORY_PATH', 'repositories/');
define('VIEW_PATH', 'views/site/');